version="0.5.0-rc.4"
tags={ "Origins" "Events" "Gameplay" }
name="吞噬之心"
supported_version="4.5.2"
picture="thumbnail.png"

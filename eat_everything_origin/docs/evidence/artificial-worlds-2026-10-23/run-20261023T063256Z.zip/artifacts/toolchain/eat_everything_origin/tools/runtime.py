"""Chinese-only isolated runtime entry; reuses the repository's desktop harness."""
import sys
import json
import os
import time
import shutil
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent
sys.path.insert(0, str(REPO / "tools"))
import stellaris_acceptance as harness

harness.MOD_ROOT = ROOT / "mod"
harness.GAME_EXE = Path(r"C:\SteamLibrary\steamapps\common\Stellaris\stellaris.exe")
harness.EXPECTED_EXE_SHA256 = "400df27c82ddc845aa9dce79bd468d81f18f060d299cd263e3afa93aef4f7a83"
harness.EXPECTED_MOD_TREE_SHA256 = harness.tree_manifest(harness.MOD_ROOT)[1]
harness.WORKSHOP_ID = "eep-local"
harness.PROFILE_ID = "heart-of-devouring-4.5.2"
harness.RUNTIME_ROOT = REPO / "_runtime/heart-of-devouring/runs"
harness.CURRENT_RUN = harness.RUNTIME_ROOT / "current-run.json"
harness.DIRECTX_REDIST_CAB = Path(r"D:\program files (x86)\steam\steamapps\common\Steamworks Shared\_CommonRedist\DirectX\Jun2010\Jun2010_d3dx9_43_x64.cab")

# Explicit opt-in; the manifest hashes the resulting fixture package.
if "--fixture" in sys.argv:
    sys.argv.remove("--fixture")
    fixture = json.loads((REPO / "_runtime/heart-of-devouring/current-fixture.json").read_text(encoding="utf-8"))
    harness.MOD_ROOT = Path(fixture["root"]) / "mod"
    harness.EXPECTED_MOD_TREE_SHA256 = harness.tree_manifest(harness.MOD_ROOT)[1]

base_settings = harness.render_pdx_settings
def windowed_settings(language):
    return base_settings(language).replace('value="borderless_fullscreen"', 'value="windowed"').replace('value="2560x1440"', 'value="1600x900"')
harness.render_pdx_settings = windowed_settings

# GDI/PrintWindow on this machine return an empty or stale desktop. Steam's
# screenshot hook captures the actual D3D9 backbuffer. Require a fresh file.
STEAM_SCREENSHOTS = Path(r"D:\program files (x86)\steam\userdata")
def screenshot_mtimes():
    """Preserve the full screenshot glob while reusing Windows directory metadata."""
    def entries(path):
        try:
            with os.scandir(path) as scan:
                return list(scan)
        except OSError:
            return []

    result = {}
    for account in entries(STEAM_SCREENSHOTS):
        try:
            directory = account.is_dir()
        except OSError:
            continue
        if not directory:
            continue
        leaf = Path(account.path) / "760/remote/281990/screenshots"
        for entry in entries(leaf):
            if os.path.normcase(entry.name).endswith(os.path.normcase(".jpg")):
                result[str(Path(entry.path))] = entry.stat().st_mtime_ns
    return result


def gpu_capture(stage):
    artifacts, _, _ = harness.load_run()
    pid = int(harness.process_record(artifacts)["pid"])
    hwnd = harness.focus_pid(pid)
    before = screenshot_mtimes()
    harness.press_scan_code(0x58, stage + "-f12", 1)
    deadline = time.monotonic() + 12
    source = None
    while time.monotonic() < deadline:
        fresh = [Path(path) for path, modified in screenshot_mtimes().items()
                 if modified > before.get(path, 0)]
        if fresh:
            source = max(fresh, key=lambda p: p.stat().st_mtime_ns)
            time.sleep(0.2)
            break
        time.sleep(0.1)
    if source is None:
        raise RuntimeError("Steam F12 did not produce a fresh GPU screenshot")
    image_path = artifacts / (stage + ".jpg")
    shutil.copyfile(source, image_path)
    from PIL import Image
    frame = Image.open(image_path)
    output = harness.RapidOCR()(frame)
    rows = []
    boxes = output.boxes if output.boxes is not None else []
    texts = output.txts if output.txts is not None else []
    scores = output.scores if output.scores is not None else []
    for box, label, score in zip(boxes, texts, scores, strict=True):
        rows.append({"text": str(label), "score": round(float(score), 5),
                     "box": [[round(float(x), 2), round(float(y), 2)] for x, y in box]})
    result = {"stage": stage, "captured_at_utc": datetime.now(timezone.utc).isoformat(),
              "pid": pid, "window_title": harness.win32gui.GetWindowText(hwnd),
              "image": str(image_path), "image_sha256": harness.sha256(image_path),
              "capture": "fresh Steam F12 GPU backbuffer", "resolution": list(frame.size),
              "client_origin": list(harness.win32gui.ClientToScreen(hwnd, (0, 0))),
              "client_rect": list(harness.win32gui.GetClientRect(hwnd)), "rows": rows}
    harness.write_json(artifacts / (stage + ".ocr.json"), result)
    return result

base_click = harness.click_point
base_scroll = harness.scroll
base_drag = harness.drag
def desktop_point(x, y):
    artifacts, _, _ = harness.load_run()
    hwnd = harness.focus_pid(int(harness.process_record(artifacts)["pid"]))
    return harness.win32gui.ClientToScreen(hwnd, (x, y))
def gpu_click(x, y, stage):
    action = base_click(*desktop_point(x, y), stage)
    action["client_point"] = [x, y]
    artifacts, _, _ = harness.load_run()
    harness.write_json(artifacts / (stage + ".action.json"), action)
    return action
def gpu_click_text(target, stage):
    result = gpu_capture(stage)
    needle = harness.normalized(target)
    choices = [r for r in result["rows"] if needle in harness.normalized(r["text"]) and r["score"] >= .5]
    if not choices:
        raise RuntimeError("OCR target not found: " + target)
    row = max(choices, key=lambda r: r["score"])
    return gpu_click(round(sum(p[0] for p in row["box"]) / 4),
                     round(sum(p[1] for p in row["box"]) / 4), stage + "-click")
def gpu_scroll(clicks, x, y, stage, repeat):
    return base_scroll(clicks, *desktop_point(x, y), stage, repeat)
def gpu_drag(x1, y1, x2, y2, duration, stage):
    return base_drag(*desktop_point(x1, y1), *desktop_point(x2, y2), duration, stage)
harness.capture = gpu_capture
harness.click_point = gpu_click
harness.click_text = gpu_click_text
harness.scroll = gpu_scroll
harness.drag = gpu_drag

base_type = harness.type_text
def physical_submit(value, submit, stage):
    artifacts, _, _ = harness.load_run()
    harness.focus_pid(int(harness.process_record(artifacts)["pid"]))
    harness.pyautogui.write(value, interval=0.04)
    action = {"action": "type_text", "stage": stage, "text": value, "submitted": False,
              "typed_at_utc": datetime.now(timezone.utc).isoformat(), "key_interval_seconds": .04}
    if submit:
        harness.press_scan_code(0x1c, stage + "-enter", 1)
        action["submitted"] = True
        action["submit_input"] = "physical scan code 0x1c"
    harness.write_json(artifacts / (stage + ".action.json"), action)
    return action
harness.type_text = physical_submit

def native_save(stage, expected_date, country_ids=()):
    """Save through Chinese native UI, then audit the newly written file."""
    import re
    import audit_save
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", stage):
        raise ValueError("save stage must be a unique ASCII filename")
    artifacts, userdir, _ = harness.load_run()
    destination = artifacts / (stage + ".sav")
    if destination.exists():
        raise RuntimeError("refusing to overwrite an archived native save")
    before = {str(p): p.stat().st_mtime_ns for p in (userdir / "save games").rglob("*.sav")}
    def exact(frame, label):
        rows = [r for r in frame["rows"] if r["text"] == label and r["score"] >= .8]
        if len(rows) != 1:
            raise RuntimeError("native UI label is missing or ambiguous: " + label)
        return rows[0]
    def click_row(row, action):
        return gpu_click(round(sum(p[0] for p in row["box"]) / 4),
                         round(sum(p[1] for p in row["box"]) / 4), action)
    for attempt in range(4):
        frame = gpu_capture(f"{stage}-menu-{attempt}")
        labels = {r["text"] for r in frame["rows"]}
        if "恢复游戏" in labels and "载入游戏" in labels:
            click_row(exact(frame, "保存游戏"), stage + "-open-save")
            break
        harness.press_scan_code(0x01, f"{stage}-esc-{attempt}", 1)
    else:
        raise RuntimeError("Chinese native main menu did not open")
    dialog = gpu_capture(stage + "-save-dialog")
    save_button = exact(dialog, "保存")
    x = round(sum(p[0] for p in save_button["box"]) / 4)
    y = round(sum(p[1] for p in save_button["box"]) / 4)
    # The name edit and save button share a row in the original save window.
    gpu_click(x - 240, y, stage + "-name-field")
    harness.press(["ctrl", "a"], 1)
    harness.type_text(stage, False, stage + "-name")
    click_row(save_button, stage + "-save-click")
    deadline = time.monotonic() + 15
    source = None
    while time.monotonic() < deadline:
        changed = [p for p in (userdir / "save games").rglob(stage + ".sav")
                   if p.stat().st_mtime_ns > before.get(str(p), 0)]
        if changed:
            source = max(changed, key=lambda p: p.stat().st_mtime_ns)
            time.sleep(1)
            break
        time.sleep(.2)
    if source is None:
        gpu_capture(stage + "-save-not-written")
        raise RuntimeError("native UI did not write the requested new save")
    shutil.copyfile(source, destination)
    result = audit_save.audit(destination, country_ids)
    harness.write_json(artifacts / (stage + ".audit.json"), result)
    if result["date"] != expected_date:
        raise RuntimeError(f"native save date differs: {result['date']} != {expected_date}")
    harness.press_scan_code(0x01, stage + "-close-menu", 1)
    save_root = (userdir / "save games").resolve()
    history = (save_root / "eep-test-history" / source.name).resolve()
    source.resolve().relative_to(save_root)
    history.relative_to(save_root)
    history.parent.mkdir(parents=True, exist_ok=True)
    if source.resolve() != history:
        if history.exists():
            raise RuntimeError("refusing to overwrite a native history save")
        source.replace(history)
    if harness.sha256(history) != result["save_sha256"]:
        raise RuntimeError("native history bytes differ from archived save")
    harness.write_json(artifacts / (stage + ".native-save.json"), {
        "written_at": str(source), "history": str(history), "archived": str(destination),
        "sha256": result["save_sha256"], "date": result["date"],
    })
    return result

def native_load(save_name, stage):
    """Select an existing unique save through native Chinese load UI.

    The caller must audit a new native save after loading to verify state.
    Missing or ambiguous OCR never falls back to a guessed slot.
    """
    import re
    import audit_save
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", stage):
        raise ValueError("load stage must be a unique ASCII label")
    artifacts, userdir, _ = harness.load_run()
    paths = list((userdir / "save games").rglob(save_name + ".sav"))
    if len(paths) != 1:
        raise RuntimeError("requested load filename is missing or ambiguous")
    source = paths[0]
    source_audit = audit_save.audit(source)
    def center(row):
        return (round(sum(p[0] for p in row["box"]) / 4),
                round(sum(p[1] for p in row["box"]) / 4))
    def exact(frame, label):
        rows = [r for r in frame["rows"] if r["text"] == label and r["score"] >= .8]
        if len(rows) != 1:
            raise RuntimeError("native load UI label is missing or ambiguous: " + label)
        return rows[0]
    for attempt in range(5):
        frame = gpu_capture(f"{stage}-menu-{attempt}")
        labels = {r["text"] for r in frame["rows"]}
        if "读取存档" in labels and "存档：" in labels:
            break
        if "载入游戏" in labels:
            # On an in-game menu this opens the load window; at the title
            # screen it is the same native action.
            gpu_click(*center(exact(frame, "载入游戏")), stage + "-open")
            frame = gpu_capture(stage + "-load-window")
            break
        harness.press_scan_code(0x01, f"{stage}-esc-{attempt}", 1)
    else:
        raise RuntimeError("Chinese native load window did not open")
    half = frame["resolution"][0] / 2
    def save_rows(frame):
        files = [r for r in frame["rows"] if r["text"] == source.name
                 and center(r)[0] > half and r["score"] >= .8]
        if files:
            return files
        return [r for r in frame["rows"] if r["text"] == save_name
                and center(r)[0] > half and r["score"] >= .8]
    def scan_list(frame, suffix):
        previous = None
        for page in range(18):
            right = save_rows(frame)
            if right:
                return frame, right
            signature = tuple(r["text"] for r in frame["rows"] if center(r)[0] > half and 350 <= center(r)[1] <= 600)
            if signature == previous:
                return frame, []
            previous = signature
            gpu_scroll(-1, round(half + 230), 530, f"{stage}-{suffix}-scroll-{page}", 12)
            frame = gpu_capture(f"{stage}-{suffix}-page-{page}")
        return frame, []
    right = save_rows(frame)
    if not right:
        parent_files = {path.name for path in source.parent.glob("*.sav")}
        left = [r for r in frame["rows"] if r["text"] in parent_files
                and center(r)[0] < half and r["score"] >= .8]
        if len(left) == 1:
            # The filename sits above a native "load latest" action in the
            # right part of the group card. Select the empire title at left.
            _, file_y = center(left[0])
            gpu_click(150, file_y - 14, stage + "-group")
            gpu_scroll(1, round(half + 230), 530, stage + "-group-top", 100)
            frame = gpu_capture(stage + "-group-selected")
            if "读取存档" not in {r["text"] for r in frame["rows"]}:
                raise RuntimeError("native group selection left the load window")
            frame, right = scan_list(frame, "group")
        else:
            frame, right = scan_list(frame, "initial")
    if len(right) != 1:
        raise RuntimeError("requested native save row is not uniquely visible")
    gpu_click(*center(right[0]), stage + "-row")
    gpu_click(*center(exact(frame, "读取存档")), stage + "-load")
    deadline = time.monotonic() + 45
    while time.monotonic() < deadline:
        time.sleep(1)
        frame = gpu_capture(stage + "-loaded")
        labels = {r["text"] for r in frame["rows"]}
        if source_audit["date"] in labels and "正在载入存档" not in labels:
            result = {"source": str(source), "source_sha256": source_audit["save_sha256"],
                      "date": source_audit["date"], "ui_date_verified": True,
                      "state_verified": False, "followup": "audit a newly saved native file",
                      "loaded_at_utc": datetime.now(timezone.utc).isoformat()}
            harness.write_json(artifacts / (stage + ".load.json"), result)
            return result
    raise RuntimeError("native load did not reach the saved date")


vanilla = "--vanilla" in sys.argv
quick = "--quick" in sys.argv
native_control_designs = "--native-control-designs" in sys.argv
if native_control_designs:
    sys.argv.remove("--native-control-designs")
    if not vanilla:
        raise ValueError("--native-control-designs requires --vanilla")
if vanilla: sys.argv.remove("--vanilla")
if quick: sys.argv.remove("--quick")
rng_seed = None
if "--rng-seed" in sys.argv:
    position = sys.argv.index("--rng-seed")
    if position + 1 >= len(sys.argv):
        raise ValueError("--rng-seed requires a 32-bit unsigned integer")
    rng_seed = int(sys.argv[position + 1])
    if not 0 <= rng_seed <= 0xFFFFFFFF:
        raise ValueError("--rng-seed must be between 0 and 4294967295")
    del sys.argv[position:position + 2]
world_seed = None
if "--world-seed" in sys.argv:
    position = sys.argv.index("--world-seed")
    if position + 1 >= len(sys.argv):
        raise ValueError("--world-seed requires a nonnegative 31-bit integer")
    world_seed = int(sys.argv[position + 1])
    if not 0 <= world_seed <= 0x7FFFFFFF:
        raise ValueError("--world-seed must be between 0 and 2147483647")
    del sys.argv[position:position + 2]
base_prepare = harness.prepare
def prepared_variant(*args, **kwargs):
    data = base_prepare(*args, **kwargs)
    # Windowed dimensions use the game's generated legacy graphics.size,
    # independently of fullscreen_resolution in pdx_settings.txt.
    legacy_settings = ('language="l_simp_chinese"\n'
                       'graphics={ size={ x=1024 y=768 } gui_scale=0.75 '
                       'fullScreen=no borderless=no renderer=1 }\n')
    legacy_path = Path(data["userdir"]) / "settings.txt"
    legacy_path.write_text(legacy_settings, encoding="utf-8", newline="\n")
    data["window_settings_sha256"] = harness.sha256(legacy_path)
    data["display"] = {"requested_mode": "windowed", "window_size_setting": [1024, 768], "gui_scale_setting": .75, "fullscreen_resolution_setting": [1600, 900], "actual": "recorded by GPU capture/client rectangle"}
    if vanilla:
        data["enabled_mods"] = []
        data["role"] = "vanilla Chinese environment control"
        harness.write_json(Path(data["userdir"]) / "dlc_load.json", {"enabled_mods": [], "disabled_dlcs": []})
    if native_control_designs:
        fixture = json.loads((REPO / "_runtime/heart-of-devouring/current-fixture.json").read_text(encoding="utf-8"))
        source = Path(fixture["root"]) / "mod/prescripted_countries/eep_probe_presets.txt"
        text = source.read_text(encoding="utf-8").replace('origin = "origin_heart_of_devouring"',
                                                         'origin = "origin_default"')
        if "origin_heart_of_devouring" in text:
            raise RuntimeError("native control design still contains the EEP origin")
        destination = Path(data["userdir"]) / "user_empire_designs_v3.4.txt"
        destination.write_text(text, encoding="utf-8", newline="\n")
        data["native_control_designs"] = {"source": str(source),
                                           "source_sha256": harness.sha256(source),
                                           "destination": str(destination),
                                           "destination_sha256": harness.sha256(destination),
                                           "runtime_verified": False}
    if quick:
        data["launch_args"].append("-quick")
        data["experimental_quick"] = True
    if rng_seed is not None:
        argument = f"-rng_seed={rng_seed}"
        data["launch_args"].append(argument)
        data["rng_seed_request"] = {"value": rng_seed, "launch_argument": argument,
                                    "actual_world_seed": "verify the native galaxy-generation log"}
    if world_seed is not None:
        argument = f"-random={world_seed}"
        data["launch_args"].append(argument)
        data["world_seed_request"] = {"value": world_seed, "launch_argument": argument,
                                      "actual_world_seed": "verify the native galaxy-generation log"}
    harness.write_json(Path(data["artifact_dir"]) / "manifest.json", data)
    return data
harness.prepare = prepared_variant

if __name__ == "__main__":
    harness.main()
